import sqlite3

DATABASE_NAME = "specsync.db"


def get_db_connection():
    conn = sqlite3.connect(DATABASE_NAME)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize_database():

    conn = get_db_connection()

    # Projects table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Requirements table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS requirements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            requirement_type TEXT NOT NULL,
            priority TEXT DEFAULT 'Medium',
            status TEXT DEFAULT 'Pending',
            version INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id)
                REFERENCES projects(id) ON DELETE CASCADE
        )
    """)

    # Requirement version history
    conn.execute("""
        CREATE TABLE IF NOT EXISTS requirement_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            requirement_id INTEGER NOT NULL,
            version_number INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (requirement_id)
                REFERENCES requirements(id) ON DELETE CASCADE
        )
    """)

    # Test cases
    conn.execute("""
        CREATE TABLE IF NOT EXISTS test_cases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            expected_result TEXT,
            status TEXT DEFAULT 'Not Executed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id)
                REFERENCES projects(id) ON DELETE CASCADE
        )
    """)

    # Requirement-to-test-case traceability
    conn.execute("""
        CREATE TABLE IF NOT EXISTS traceability_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            requirement_id INTEGER NOT NULL,
            test_case_id INTEGER NOT NULL,
            FOREIGN KEY (requirement_id)
                REFERENCES requirements(id) ON DELETE CASCADE,
            FOREIGN KEY (test_case_id)
                REFERENCES test_cases(id) ON DELETE CASCADE,
            UNIQUE(requirement_id, test_case_id)
        )
    """)

    conn.commit()
    conn.close()

    print("SpecSync database initialized successfully!")


if __name__ == "__main__":
    initialize_database()