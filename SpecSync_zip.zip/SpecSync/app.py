
from flask import Flask, render_template, request, redirect, url_for
from database import initialize_database, get_db_connection

app = Flask(__name__)

initialize_database()


def ensure_app_schema():
    """Add the test execution status column while preserving existing records."""
    conn = get_db_connection()
    columns = {row[1] for row in conn.execute("PRAGMA table_info(test_cases)").fetchall()}
    if "status" not in columns:
        conn.execute("ALTER TABLE test_cases ADD COLUMN status TEXT NOT NULL DEFAULT 'Not Executed'")
    # Correct the known typo in existing project records.
    conn.execute("""
        UPDATE projects SET name = 'student management'
        WHERE LOWER(TRIM(name)) IN ('student mangement', 'student managment')
    """)
    conn.commit()
    conn.close()


ensure_app_schema()


# ==============================
# Dashboard
# ==============================

@app.route("/")
def home():
    conn = get_db_connection()

    total_projects = conn.execute(
        "SELECT COUNT(*) FROM projects"
    ).fetchone()[0]

    total_requirements = conn.execute(
        "SELECT COUNT(*) FROM requirements"
    ).fetchone()[0]

    total_versions = conn.execute(
        "SELECT COUNT(*) FROM requirement_versions"
    ).fetchone()[0]

    total_test_cases = conn.execute(
        "SELECT COUNT(*) FROM test_cases"
    ).fetchone()[0]

    executed_test_cases = conn.execute("""
        SELECT COUNT(*) FROM test_cases WHERE status IN ('Pass', 'Fail')
    """).fetchone()[0]

    projects = conn.execute(
        "SELECT * FROM projects ORDER BY id DESC"
    ).fetchall()

    conn.close()

    return render_template(
        "dashboard.html",
        projects=projects,
        total_projects=total_projects,
        total_requirements=total_requirements,
        total_versions=total_versions,
        total_test_cases=total_test_cases,
        executed_test_cases=executed_test_cases
    )


# ==============================
# Projects
# ==============================

@app.route("/projects")
def projects():
    return redirect(url_for("home"))


@app.route("/add_project", methods=["POST"])
def add_project():
    name = request.form.get("name", "").strip()
    description = request.form.get("description", "").strip()

    if not name:
        return redirect(url_for("home"))

    conn = get_db_connection()

    conn.execute(
        "INSERT INTO projects (name, description) VALUES (?, ?)",
        (name, description)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("home"))


@app.route("/delete_project/<int:project_id>", methods=["POST"])
def delete_project(project_id):
    conn = get_db_connection()

    # Remove related traceability links
    conn.execute("""
        DELETE FROM traceability_links
        WHERE requirement_id IN (
            SELECT id FROM requirements WHERE project_id = ?
        )
        OR test_case_id IN (
            SELECT id FROM test_cases WHERE project_id = ?
        )
    """, (project_id, project_id))

    # Remove requirement versions
    conn.execute("""
        DELETE FROM requirement_versions
        WHERE requirement_id IN (
            SELECT id FROM requirements WHERE project_id = ?
        )
    """, (project_id,))

    # Remove requirements and test cases
    conn.execute(
        "DELETE FROM requirements WHERE project_id = ?",
        (project_id,)
    )

    conn.execute(
        "DELETE FROM test_cases WHERE project_id = ?",
        (project_id,)
    )

    conn.execute(
        "DELETE FROM projects WHERE id = ?",
        (project_id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("home"))


# ==============================
# Requirements Management
# ==============================

@app.route("/requirements")
def requirements():
    conn = get_db_connection()

    projects = conn.execute(
        "SELECT * FROM projects ORDER BY id DESC"
    ).fetchall()

    all_requirements = conn.execute("""
        SELECT requirements.*, projects.name AS project_name
        FROM requirements
        JOIN projects ON requirements.project_id = projects.id
        ORDER BY requirements.id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "requirements.html",
        projects=projects,
        requirements=all_requirements
    )


@app.route("/add_requirement", methods=["POST"])
def add_requirement():
    project_id = request.form.get("project_id", "")
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    requirement_type = request.form.get("requirement_type", "").strip()
    priority = request.form.get("priority", "Medium").strip()

    if not project_id or not title or not requirement_type:
        return redirect(url_for("requirements"))

    conn = get_db_connection()

    project = conn.execute(
        "SELECT id FROM projects WHERE id = ?",
        (project_id,)
    ).fetchone()

    if project is None:
        conn.close()
        return redirect(url_for("requirements"))

    cursor = conn.execute("""
        INSERT INTO requirements
        (project_id, title, description, requirement_type, priority)
        VALUES (?, ?, ?, ?, ?)
    """, (
        project_id,
        title,
        description,
        requirement_type,
        priority or "Medium"
    ))

    requirement_id = cursor.lastrowid

    # Save initial requirement version
    conn.execute("""
        INSERT INTO requirement_versions
        (requirement_id, version_number, title, description)
        VALUES (?, 1, ?, ?)
    """, (
        requirement_id,
        title,
        description
    ))

    conn.commit()
    conn.close()

    return redirect(url_for("requirements"))


@app.route("/update_requirement/<int:requirement_id>", methods=["POST"])
def update_requirement(requirement_id):
    """Update a requirement and store its previous content as a new history entry."""
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    requirement_type = request.form.get("requirement_type", "").strip()
    priority = request.form.get("priority", "Medium").strip() or "Medium"

    if not title or not requirement_type:
        return redirect(url_for("requirements"))

    conn = get_db_connection()
    current = conn.execute(
        "SELECT * FROM requirements WHERE id = ?", (requirement_id,)
    ).fetchone()
    if current is None:
        conn.close()
        return redirect(url_for("requirements"))

    changed = (
        current["title"] != title
        or current["description"] != description
        or current["requirement_type"] != requirement_type
        or current["priority"] != priority
    )

    if changed:
        next_version = conn.execute("""
            SELECT COALESCE(MAX(version_number), 0) + 1
            FROM requirement_versions WHERE requirement_id = ?
        """, (requirement_id,)).fetchone()[0]

        conn.execute("""
            UPDATE requirements
            SET title = ?, description = ?, requirement_type = ?, priority = ?
            WHERE id = ?
        """, (title, description, requirement_type, priority, requirement_id))

        # Record the new requirement content as the next version.
        conn.execute("""
            INSERT INTO requirement_versions
                (requirement_id, version_number, title, description)
            VALUES (?, ?, ?, ?)
        """, (requirement_id, next_version, title, description))

    conn.commit()
    conn.close()
    return redirect(url_for("requirements"))


@app.route("/delete_requirement/<int:requirement_id>", methods=["POST"])
def delete_requirement(requirement_id):
    conn = get_db_connection()

    conn.execute(
        "DELETE FROM traceability_links WHERE requirement_id = ?",
        (requirement_id,)
    )

    conn.execute(
        "DELETE FROM requirement_versions WHERE requirement_id = ?",
        (requirement_id,)
    )

    conn.execute(
        "DELETE FROM requirements WHERE id = ?",
        (requirement_id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("requirements"))


# ==============================
# Version History
# ==============================

@app.route("/versions")
def versions():
    conn = get_db_connection()

    all_versions = conn.execute("""
        SELECT
            requirement_versions.*,
            requirements.title AS requirement_title,
            projects.name AS project_name
        FROM requirement_versions
        JOIN requirements
            ON requirement_versions.requirement_id = requirements.id
        JOIN projects
            ON requirements.project_id = projects.id
        ORDER BY requirement_versions.id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "versions.html",
        versions=all_versions
    )


# ==============================
# Test Case Management
# ==============================

@app.route("/test_cases")
def test_cases():

    conn = get_db_connection()

    projects = conn.execute(
        "SELECT * FROM projects ORDER BY id DESC"
    ).fetchall()

    all_test_cases = conn.execute("""
        SELECT test_cases.*, projects.name AS project_name
        FROM test_cases
        JOIN projects ON test_cases.project_id = projects.id
        ORDER BY test_cases.id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "test_cases.html",
        projects=projects,
        test_cases=all_test_cases
    )


@app.route("/add_test_case", methods=["POST"])
def add_test_case():

    project_id = request.form.get("project_id", "").strip()
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    expected_result = request.form.get("expected_result", "").strip()

    if not project_id or not title:
        return redirect(url_for("test_cases"))

    try:
        project_id = int(project_id)
    except ValueError:
        return redirect(url_for("test_cases"))

    conn = get_db_connection()

    project = conn.execute(
        "SELECT id FROM projects WHERE id = ?",
        (project_id,)
    ).fetchone()

    if project is None:
        conn.close()
        return redirect(url_for("test_cases"))

    conn.execute("""
        INSERT INTO test_cases
        (project_id, title, description, expected_result, status)
        VALUES (?, ?, ?, ?, 'Not Executed')
    """, (
        project_id,
        title,
        description,
        expected_result
    ))

    conn.commit()
    conn.close()

    return redirect(url_for("test_cases"))


@app.route("/update_test_case_status/<int:test_case_id>", methods=["POST"])
def update_test_case_status(test_case_id):
    """Update test execution status using an allowed value only."""
    status = request.form.get("status", "").strip()
    if status not in {"Pass", "Fail", "Not Executed"}:
        return redirect(url_for("test_cases"))

    conn = get_db_connection()
    conn.execute(
        "UPDATE test_cases SET status = ? WHERE id = ?",
        (status, test_case_id)
    )
    conn.commit()
    conn.close()
    return redirect(url_for("test_cases"))


@app.route("/delete_test_case/<int:test_case_id>", methods=["POST"])
def delete_test_case(test_case_id):

    conn = get_db_connection()

    conn.execute(
        "DELETE FROM test_cases WHERE id = ?",
        (test_case_id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("test_cases"))

# ==============================
# Traceability Matrix
# ==============================

@app.route("/traceability")
def traceability():
    conn = get_db_connection()

    requirements = conn.execute("""
        SELECT r.id, r.title, p.name AS project_name
        FROM requirements r
        JOIN projects p ON r.project_id = p.id
        ORDER BY r.id DESC
    """).fetchall()

    test_cases = conn.execute("""
        SELECT t.id, t.title, p.name AS project_name
        FROM test_cases t
        JOIN projects p ON t.project_id = p.id
        ORDER BY t.id DESC
    """).fetchall()

    links = conn.execute("""
        SELECT
            tl.id,
            r.title AS requirement_title,
            p.name AS project_name,
            t.title AS test_case_title
        FROM traceability_links tl
        JOIN requirements r ON tl.requirement_id = r.id
        JOIN projects p ON r.project_id = p.id
        JOIN test_cases t ON tl.test_case_id = t.id
        ORDER BY tl.id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "traceability.html",
        requirements=requirements,
        test_cases=test_cases,
        links=links
    )


@app.route("/add_traceability_link", methods=["POST"])
def add_traceability_link():
    requirement_id = request.form.get("requirement_id")
    test_case_id = request.form.get("test_case_id")

    if not requirement_id or not test_case_id:
        return redirect(url_for("traceability"))

    conn = get_db_connection()

    # Ensure both belong to the same project
    valid = conn.execute("""
        SELECT 1
        FROM requirements r
        JOIN test_cases t ON r.project_id = t.project_id
        WHERE r.id = ? AND t.id = ?
    """, (requirement_id, test_case_id)).fetchone()

    if valid:
        conn.execute("""
            INSERT OR IGNORE INTO traceability_links
            (requirement_id, test_case_id)
            VALUES (?, ?)
        """, (requirement_id, test_case_id))

        conn.commit()

    conn.close()

    return redirect(url_for("traceability"))


@app.route("/delete_traceability_link/<int:link_id>", methods=["POST"])
def delete_traceability_link(link_id):
    conn = get_db_connection()

    conn.execute(
        "DELETE FROM traceability_links WHERE id = ?",
        (link_id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("traceability"))


# ==============================
# Reports
# ==============================

@app.route("/reports")
def reports():
    conn = get_db_connection()

    total_projects = conn.execute(
        "SELECT COUNT(*) FROM projects"
    ).fetchone()[0]

    total_requirements = conn.execute(
        "SELECT COUNT(*) FROM requirements"
    ).fetchone()[0]

    total_test_cases = conn.execute(
        "SELECT COUNT(*) FROM test_cases"
    ).fetchone()[0]

    total_versions = conn.execute(
        "SELECT COUNT(*) FROM requirement_versions"
    ).fetchone()[0]

    total_links = conn.execute(
        "SELECT COUNT(*) FROM traceability_links"
    ).fetchone()[0]

    passed_test_cases = conn.execute(
        "SELECT COUNT(*) FROM test_cases WHERE status = 'Pass'"
    ).fetchone()[0]
    failed_test_cases = conn.execute(
        "SELECT COUNT(*) FROM test_cases WHERE status = 'Fail'"
    ).fetchone()[0]
    not_executed_test_cases = conn.execute(
        "SELECT COUNT(*) FROM test_cases WHERE status = 'Not Executed'"
    ).fetchone()[0]

    linked_requirements = conn.execute("""
        SELECT COUNT(DISTINCT requirement_id)
        FROM traceability_links
    """).fetchone()[0]

    # Coverage is the percentage of requirements linked to at least one test case.
    coverage = round(
        linked_requirements * 100.0 / total_requirements, 2
    ) if total_requirements else 0.0

    project_reports = conn.execute("""
        SELECT
            p.id,
            p.name,

            (SELECT COUNT(*)
             FROM requirements r
             WHERE r.project_id = p.id) AS requirements_count,

            (SELECT COUNT(*)
             FROM test_cases t
             WHERE t.project_id = p.id) AS test_cases_count,

            (SELECT COUNT(DISTINCT tl.requirement_id)
             FROM traceability_links tl
             JOIN requirements r ON r.id = tl.requirement_id
             WHERE r.project_id = p.id) AS linked_count

        FROM projects p
        ORDER BY p.id DESC
    """).fetchall()

    conn.close()

    reports_data = []

    for project in project_reports:
        req_count = project["requirements_count"]
        linked_count = project["linked_count"]

        project_coverage = round(
            linked_count * 100 / req_count, 2
        ) if req_count else 0

        reports_data.append({
            "name": project["name"],
            "requirements_count": req_count,
            "test_cases_count": project["test_cases_count"],
            "linked_count": linked_count,
            "coverage": project_coverage
        })

    return render_template(
        "reports.html",
        total_projects=total_projects,
        total_requirements=total_requirements,
        total_test_cases=total_test_cases,
        total_versions=total_versions,
        total_links=total_links,
        coverage=coverage,
        passed_test_cases=passed_test_cases,
        failed_test_cases=failed_test_cases,
        not_executed_test_cases=not_executed_test_cases,
        project_reports=reports_data
    )


# ==============================
# Run Application
# ==============================

if __name__ == "__main__":
    app.run(debug=True)
